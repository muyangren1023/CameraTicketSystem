package com.movie.api.model.dto;

public class CreateCartDto {
}
