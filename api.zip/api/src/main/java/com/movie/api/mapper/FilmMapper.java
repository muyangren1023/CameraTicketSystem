package com.movie.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.movie.api.model.entity.Film;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import java.util.List;

@Mapper
public interface FilmMapper extends BaseMapper<Film> {
    @Select("SELECT * FROM (SELECT id, name, release_time, type, status, region, introduction, hot, cover, duration " +
            "FROM t_film ORDER BY hot DESC) WHERE ROWNUM <= 10")
    List<Film> selectTopHotFilms(@Param("limit") int limit);
}
