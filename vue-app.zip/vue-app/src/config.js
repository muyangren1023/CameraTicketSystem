//自定义的配置文件
const config = {
    //后端api地址
    API_URL: "http://localhost:8888/api",
};

export default config
