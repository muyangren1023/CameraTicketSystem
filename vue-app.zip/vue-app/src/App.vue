<template>
    <router-view />
</template>

<style>
    body {
        width: 100%;
        min-width: 1500px;
        height: 100%;
        margin: 0;
    }

    a{
        text-decoration: none;
    }
</style>
