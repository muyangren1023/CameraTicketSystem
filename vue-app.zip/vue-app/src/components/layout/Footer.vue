<template>
  <div class="footer">
    <p> Copyright 2024 鹌鹑影院</p>
  </div>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>
.footer {
  height: 70px;
  text-align: center;
  letter-spacing: 2px;
  font-size: 13px;
  color: darkgray;
}
</style>
