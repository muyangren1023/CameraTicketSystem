//自定义的配置文件
const config = {
    //后端api地址
    API_URL: "http://localhost:8888/api",
    SWAGGER_URL: 'http://localhost:8888/swagger-ui.html',
};

export default config
